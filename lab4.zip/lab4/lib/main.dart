import 'dart:math';

import 'package:flutter/material.dart';

class InputInfo {
  final double price;
  final double rate;
  final int year;
  final double result;
  final double monthly;

  const InputInfo(this.price, this.rate, this.year, this.result, this.monthly);
}

double monthlyPayment(double amount, double rate, int years) {
  if (rate == 0) return amount / (years * 12);

  double mRate = (rate / 100) / 12;
  double temp = pow(1 / (1 + mRate), years * 12).toDouble();

  if (temp == 1) return amount / (years * 12);
  return amount * mRate / (1 - temp);
}

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        scaffoldBackgroundColor: const Color(0xFFF4F6FA),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.indigo,
            foregroundColor: Colors.white,
          ),
        ),
      ),
      home: const MortgageCalculator(),
    );
  }
}

class MortgageCalculator extends StatefulWidget {
  const MortgageCalculator({super.key});

  @override
  State<MortgageCalculator> createState() => _MortgageCalculatorState();
}

class _MortgageCalculatorState extends State<MortgageCalculator> {
  final TextEditingController _priceController = TextEditingController();
  final TextEditingController _rateController = TextEditingController();

  int _selectedyear = 10;
  bool _acceptedTerms = false;
  bool _showingTerms = false;
  String? _priceError;
  String? _rateError;

  @override
  void dispose() {
    _priceController.dispose();
    _rateController.dispose();
    super.dispose();
  }

  void _calculateMortgage() {
    double? price = double.tryParse(_priceController.text.trim());
    double? rate = double.tryParse(_rateController.text.trim());

    bool validPrice = price != null && price.isFinite && price >= 0;
    bool validRate = rate != null && rate.isFinite && rate >= 0;
    setState(() {
      _priceError = validPrice ? null : 'Enter a valid amount of 0 or more.';
      _rateError = validRate
          ? null
          : 'Enter a valid interest rate of 0 or more.';
    });
    if (!validPrice || !validRate) return;

    double monthly = monthlyPayment(price, rate, _selectedyear);
    double total = monthly * (_selectedyear * 12);
    if (!monthly.isFinite || !total.isFinite) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('These values are too large to calculate.'),
        ),
      );
      return;
    }

    final InputInfo finalcalc = InputInfo(
      price,
      rate / 100,
      _selectedyear,
      total,
      monthly,
    );
    FocusScope.of(context).unfocus();
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => CalculationScreen(finalcalc)),
    );
  }

  Future<void> _confirmTerms(bool? value) async {
    if (_showingTerms) return;
    if (value != true) {
      setState(() => _acceptedTerms = false);
      return;
    }

    _showingTerms = true;
    bool? accepted = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Terms and Conditions'),
        content: const Text('Please confirm you agree to the terms.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('OK'),
          ),
        ],
      ),
    );
    if (!mounted) return;
    setState(() {
      _showingTerms = false;
      _acceptedTerms = accepted == true;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Mortgage Calculator',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.indigo,
      ),
      body: SingleChildScrollView(
        keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.all(16),
              child: TextField(
                controller: _priceController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: InputDecoration(
                  labelText: 'Amount',
                  errorText: _priceError,
                  errorMaxLines: 2,
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.all(16),
              child: TextField(
                controller: _rateController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: InputDecoration(
                  labelText: 'Interest Rate %',
                  errorText: _rateError,
                  errorMaxLines: 2,
                ),
              ),
            ),
            RadioGroup<int>(
              groupValue: _selectedyear,
              onChanged: (value) {
                if (value != null) setState(() => _selectedyear = value);
              },
              child: Container(
                margin: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    const Text('Years:'),
                    Expanded(
                      child: RadioListTile<int>(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('10'),
                        value: 10,
                      ),
                    ),
                    Expanded(
                      child: RadioListTile<int>(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('15'),
                        value: 15,
                      ),
                    ),
                    Expanded(
                      child: RadioListTile<int>(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('30'),
                        value: 30,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Checkbox(value: _acceptedTerms, onChanged: _confirmTerms),
                const Flexible(child: Text('Terms and Conditions')),
              ],
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _calculateMortgage,
              child: const Text('Done'),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class CalculationScreen extends StatelessWidget {
  final InputInfo results;

  const CalculationScreen(this.results, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Calculation Results',
          style: TextStyle(color: Colors.white),
        ),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.indigo,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            spacing: 8,
            children: [
              Container(
                decoration: BoxDecoration(
                  color: Colors.indigo,
                  borderRadius: BorderRadius.circular(12),
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  spacing: 8,
                  children: [
                    Text(
                      'Amount: \$${results.price.toStringAsFixed(2)}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                    ),
                    Text(
                      'Years: ${results.year}',
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                    ),
                    Text(
                      'Interest Rate: ${(results.rate * 100).toStringAsFixed(2)}%',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                    ),
                    Text(
                      'Monthly Payment: \$${results.monthly.toStringAsFixed(2)}',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 16),
                    ),
                  ],
                ),
              ),
              Text(
                'Total with Interest: \$${results.result.toStringAsFixed(2)}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 22),
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('Modify Data'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
